CREATE VIEW contact_view2 AS
  SELECT max(contact."Id") AS "Id",
    contact."Name"
   FROM contact
  GROUP BY contact."Name"
 HAVING (count(1) > 1);

