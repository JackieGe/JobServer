CREATE VIEW contact_view AS
  SELECT contact."Id",
    contact."Name"
   FROM contact;

