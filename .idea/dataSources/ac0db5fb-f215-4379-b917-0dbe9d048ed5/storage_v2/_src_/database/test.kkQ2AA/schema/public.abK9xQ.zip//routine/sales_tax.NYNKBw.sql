CREATE FUNCTION sales_tax(subtotal real)
  RETURNS real
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN subtotal * 0.06;
END;
$$;

