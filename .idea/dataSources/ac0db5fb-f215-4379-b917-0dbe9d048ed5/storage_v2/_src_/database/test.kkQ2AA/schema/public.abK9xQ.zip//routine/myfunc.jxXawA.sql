CREATE FUNCTION myfunc()
  RETURNS timestamp without time zone
LANGUAGE plpgsql
AS $$
begin
	if true then
    	perform (select now());
        return now();
    end if;
end;
$$;

