CREATE FUNCTION pymax(anyelement, anyelement)
  RETURNS integer
LANGUAGE plpgsql
AS $$
declare
	a alias for $1;
    b alias for $2;
begin
    IF a > b then
        return a;
    else
        return b;
    end if;
end;
$$;

