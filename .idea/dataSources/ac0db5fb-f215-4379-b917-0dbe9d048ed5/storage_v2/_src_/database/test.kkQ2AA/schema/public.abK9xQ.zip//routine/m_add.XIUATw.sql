CREATE FUNCTION m_add(a integer)
  RETURNS SETOF contact
LANGUAGE plpgsql
AS $$
begin
	-- return 1;
   -- select 2;
   return query select * from public.contact;
   -- return 1;
end;
$$;

